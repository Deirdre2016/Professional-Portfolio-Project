-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2016 at 05:02 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";



/*SELECT COLUMN NAME FROM TABLE. */ 

SELECT address_id
FROM customer_address;
Collapse Edit Queried time: 3:54:58

/*SELECT ALL DATA FROM TABLE CUSTOMER_ADDRESS. */

SELECT * FROM customer_address;
Collapse Edit Queried time: 4:6:14
/*INSERTING INTO BRANDS TABLE, VALUES FOR BRAND_ID, BRAND_NAME, BRAND_DETAILS. */