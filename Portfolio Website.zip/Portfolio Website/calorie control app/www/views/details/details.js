angular.module('CalorieApp')
.controller('DetailsController', function ($scope, Bal) {

  $scope.bal = Bal;

});
