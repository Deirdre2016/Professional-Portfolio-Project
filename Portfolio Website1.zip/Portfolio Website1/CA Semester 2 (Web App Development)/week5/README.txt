1. On Moodle go to Javascript Events Lab 3 under the Labs section.

2. Just download the zip file, unzip it, and review the html and js files syntax. Make sure to read the comments.

3. Run some tests on the web page, to get a feel for the event object.

4. Feel free to update the html, and js to run some other tests to ensure you understand the event object.

