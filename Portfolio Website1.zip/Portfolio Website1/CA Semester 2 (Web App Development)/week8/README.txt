No pdf included with this lab outlining exercises.

Exercise was outlined on the board with outline of web page and explanation of document.write() function.

Have just included the solution.

Please load the html file and review the js file. Note that the web page is created entirely from js using document.write().