/*UPDATING CUSTOMERS_ADDRESS. */


UPDATE Customer_address
SET City='Bray'
WHERE city=co. wicklow;
Collapse Edit Queried time: 4:37:18

/*UPDATING CUSTOMERS_ADDRESS. */
UPDATE Customer_address
SET City='Bray'
WHERE city='Bray';
Collapse Edit Queried time: 4:40:56

/*UPDATING CUSTOMERS_ADDRESS. */
UPDATE Customer_address
SET City='London'
WHERE city='CO.GALWAY';
Collapse Edit Queried time: 4:48:46


