/*DELETING CUSTOMER FROM TABLE CUSTOMER_ADDRESS. */


DELETE FROM Customers
WHERE Last_Name='Jones' AND First_Name='Lucy';

/*DELETING COLUMN FROM TABLE CUSTOMER_ADDRESS. */

DELETE FROM customer_address
WHERE country='IRELAND;
Collapse Edit Queried time: 4:50:5